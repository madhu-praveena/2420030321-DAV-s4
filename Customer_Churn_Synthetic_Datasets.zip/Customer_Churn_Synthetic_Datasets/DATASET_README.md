# Customer Churn Synthetic Datasets

## Important provenance note
These files are **synthetic, programmatically generated data**. They are not IBM customer records,
not collected from a real telecom company, and not the official IBM Telco Customer Churn dataset.
They are suitable for learning, testing preprocessing/model pipelines, and demonstrating a workflow.
Do not describe results from these files as results on real customers or as official IBM benchmark results.

## Files
- `telco_customer_churn_synthetic.csv`: 7,043 synthetic labelled rows; 21 columns.
- `telco_customer_churn_sample_500.csv`: 500-row sample from the synthetic labelled dataset.
- `telco_customer_scoring_unlabelled_300.csv`: 300 synthetic customer rows without the `Churn` target.

## Target
- `Churn = Yes`: synthetic customer is labelled as churned.
- `Churn = No`: synthetic customer is labelled as retained.

## Columns
The schema follows the commonly used Telco Customer Churn-style field names:
customerID, gender, SeniorCitizen, Partner, Dependents, tenure, PhoneService,
MultipleLines, InternetService, OnlineSecurity, OnlineBackup, DeviceProtection,
TechSupport, StreamingTV, StreamingMovies, Contract, PaperlessBilling,
PaymentMethod, MonthlyCharges, TotalCharges, Churn.

## Data characteristics
- `customerID` is an identifier; exclude it from model predictors.
- `SeniorCitizen` is binary (0/1).
- Most other service/profile fields are categorical.
- `tenure`, `MonthlyCharges`, and `TotalCharges` are numeric.
- Some `TotalCharges` values are intentionally missing to exercise imputation.
- Churn labels were generated from a probabilistic rule using contract, tenure, service,
  payment and billing attributes, with random noise. This creates learnable patterns by design.

## Suggested academic use
1. Load the CSV and inspect `shape`, `head`, `info`, `describe`, and target counts.
2. Check missing values and duplicates.
3. Split train/test with stratification.
4. Fit imputers, encoders and scalers only on training data using a Pipeline/ColumnTransformer.
5. Compare classifiers using accuracy, precision, recall, F1 and ROC-AUC.
6. Clearly state in your report that the dataset is synthetic.

## Reproducibility
Generation seed: 42 for the main dataset. The dataset-generation script is not included in this archive;
the files are fixed snapshots of one generated run.
