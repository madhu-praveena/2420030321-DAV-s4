"""Download the IBM Telco Customer Churn sample CSV."""
from pathlib import Path
from urllib.request import urlretrieve

URL = "https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv"
DEST = Path(__file__).resolve().parents[1] / "data" / "raw" / "Telco-Customer-Churn.csv"


def main() -> None:
    DEST.parent.mkdir(parents=True, exist_ok=True)
    if DEST.exists() and DEST.stat().st_size > 100_000:
        print(f"Dataset already exists: {DEST}")
        return
    print(f"Downloading dataset from IBM source to {DEST} ...")
    urlretrieve(URL, DEST)
    if DEST.stat().st_size < 100_000:
        DEST.unlink(missing_ok=True)
        raise RuntimeError("Downloaded file is unexpectedly small; check the source URL.")
    print(f"Downloaded {DEST.stat().st_size:,} bytes.")


if __name__ == "__main__":
    main()
