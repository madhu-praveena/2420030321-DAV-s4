"""Train and evaluate churn classifiers on the IBM Telco sample dataset."""
from __future__ import annotations

import json
import warnings
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score, RocCurveDisplay,
)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "raw" / "Telco-Customer-Churn.csv"
RESULTS = ROOT / "results"
MODELS = ROOT / "models"
SEED = 42


def load_data() -> pd.DataFrame:
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found at {DATA_PATH}. Run `python -m src.download_data` first."
        )
    df = pd.read_csv(DATA_PATH)
    required = {"Churn", "customerID"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV is missing required columns: {sorted(required - set(df.columns))}")
    df = df.copy()
    if "TotalCharges" in df.columns:
        df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df = df[df["Churn"].isin(["Yes", "No"])].copy()
    df["Churn"] = df["Churn"].map({"No": 0, "Yes": 1}).astype(int)
    return df


def build_preprocessor(numeric_cols: list[str], categorical_cols: list[str], scale: bool) -> ColumnTransformer:
    numeric_steps = [("imputer", SimpleImputer(strategy="median"))]
    if scale:
        numeric_steps.append(("scaler", StandardScaler()))
    numeric_pipe = Pipeline(numeric_steps)
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, numeric_cols),
        ("categorical", categorical_pipe, categorical_cols),
    ], remainder="drop")


def make_models(numeric_cols: list[str], categorical_cols: list[str]):
    specs = {
        "Logistic Regression": (LogisticRegression(max_iter=2000, class_weight="balanced", random_state=SEED), True),
        "Decision Tree": (DecisionTreeClassifier(random_state=SEED, class_weight="balanced", min_samples_leaf=5), False),
        "Random Forest": (RandomForestClassifier(n_estimators=350, random_state=SEED, class_weight="balanced", min_samples_leaf=2, n_jobs=-1), False),
        "SVM": (SVC(C=1.0, kernel="rbf", probability=True, class_weight="balanced", random_state=SEED), True),
        "KNN": (KNeighborsClassifier(n_neighbors=11, weights="distance"), True),
    }
    try:
        from xgboost import XGBClassifier
        specs["XGBoost"] = (XGBClassifier(
            n_estimators=350, max_depth=4, learning_rate=0.04,
            subsample=0.9, colsample_bytree=0.9, reg_lambda=1.0,
            eval_metric="logloss", random_state=SEED, n_jobs=-1,
        ), False)
    except Exception as exc:
        warnings.warn(f"XGBoost unavailable; skipping it ({exc}).")
    pipelines = {}
    for name, (estimator, scale) in specs.items():
        pipelines[name] = Pipeline([
            ("preprocess", build_preprocessor(numeric_cols, categorical_cols, scale)),
            ("classifier", estimator),
        ])
    return pipelines


def write_quality_report(df_raw: pd.DataFrame, df: pd.DataFrame) -> None:
    target_counts = df["Churn"].value_counts().sort_index().to_dict()
    numeric = df.drop(columns=["customerID", "Churn"], errors="ignore").select_dtypes(include=np.number)
    skew = numeric.skew(numeric_only=True).replace({np.nan: None}).to_dict()
    outliers = {}
    for col in numeric.columns:
        q1, q3 = numeric[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        outliers[col] = int(((numeric[col] < low) | (numeric[col] > high)).sum())
    quality = {
        "raw_shape": [int(x) for x in df_raw.shape],
        "modeling_shape_before_split": [int(x) for x in df.shape],
        "columns": list(df_raw.columns),
        "dtypes": {k: str(v) for k, v in df_raw.dtypes.items()},
        "missing_values_in_raw_csv_as_read": {k: int(v) for k, v in df_raw.isna().sum().items()},
        "missing_values_after_numeric_type_conversion_before_imputation": {k: int(v) for k, v in df.isna().sum().items()},
        "duplicate_rows": int(df_raw.duplicated().sum()),
        "duplicate_customer_ids": int(df_raw["customerID"].duplicated().sum()) if "customerID" in df_raw else None,
        "churn_counts": {str(k): int(v) for k, v in target_counts.items()},
        "churn_rate": float(df["Churn"].mean()),
        "numeric_skewness": skew,
        "iqr_outlier_counts": outliers,
    }
    (RESULTS / "data_quality.json").write_text(json.dumps(quality, indent=2, default=str), encoding="utf-8")


def main() -> None:
    RESULTS.mkdir(exist_ok=True)
    MODELS.mkdir(exist_ok=True)
    df_raw = pd.read_csv(DATA_PATH) if DATA_PATH.exists() else None
    if df_raw is None:
        raise FileNotFoundError("Dataset missing. Run `python -m src.download_data` first.")
    df = load_data()
    write_quality_report(df_raw, df)

    X = df.drop(columns=["Churn", "customerID"], errors="ignore")
    y = df["Churn"]
    numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=np.number).columns.tolist()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=SEED, stratify=y
    )

    models = make_models(numeric_cols, categorical_cols)
    rows, reports, fitted = [], {}, {}
    fig, ax = plt.subplots(figsize=(8, 6))
    for name, pipeline in models.items():
        print(f"Training {name} ...")
        pipeline.fit(X_train, y_train)
        pred = pipeline.predict(X_test)
        if hasattr(pipeline, "predict_proba"):
            prob = pipeline.predict_proba(X_test)[:, 1]
        else:
            prob = pipeline.decision_function(X_test)
        metrics = {
            "Model": name,
            "Accuracy": accuracy_score(y_test, pred),
            "Precision": precision_score(y_test, pred, zero_division=0),
            "Recall": recall_score(y_test, pred, zero_division=0),
            "F1-score": f1_score(y_test, pred, zero_division=0),
            "ROC-AUC": roc_auc_score(y_test, prob),
        }
        rows.append(metrics)
        reports[name] = {
            "classification_report": classification_report(y_test, pred, output_dict=True, zero_division=0),
            "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
        }
        fitted[name] = pipeline
        RocCurveDisplay.from_predictions(y_test, prob, name=name, ax=ax)

    metrics_df = pd.DataFrame(rows).sort_values(
        ["F1-score", "Recall", "ROC-AUC"], ascending=False
    )
    metrics_df.to_csv(RESULTS / "model_metrics.csv", index=False, float_format="%.6f")
    (RESULTS / "classification_reports.json").write_text(json.dumps(reports, indent=2), encoding="utf-8")
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1)
    ax.set_title("ROC Curves — Customer Churn Models")
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(RESULTS / "roc_curves.png", dpi=180)
    plt.close(fig)

    churn_counts = df["Churn"].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(["Stayed (0)", "Churned (1)"], [int(churn_counts.get(0, 0)), int(churn_counts.get(1, 0))])
    ax.set_title("Customer Churn Class Distribution")
    ax.set_ylabel("Number of customers")
    fig.tight_layout()
    fig.savefig(RESULTS / "churn_distribution.png", dpi=180)
    plt.close(fig)

    best_name = str(metrics_df.iloc[0]["Model"])
    joblib.dump(fitted[best_name], MODELS / "best_model.joblib")
    metadata = {
        "random_state": SEED,
        "test_size": 0.20,
        "stratified": True,
        "training_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "features_used": list(X.columns),
        "numeric_features": numeric_cols,
        "categorical_features": categorical_cols,
        "best_model_by_f1_then_recall_then_roc_auc": best_name,
        "best_model_metrics": {k: float(v) if isinstance(v, (np.floating, float)) else v for k, v in metrics_df.iloc[0].to_dict().items()},
        "xgboost_included": "XGBoost" in models,
    }
    (RESULTS / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("\nModel comparison (held-out test set):")
    print(metrics_df.to_string(index=False, formatters={c: (lambda x: f"{x:.4f}") for c in metrics_df.columns if c != "Model"}))
    print(f"\nSelected model: {best_name}")
    print(f"Saved metrics and plots under {RESULTS}")


if __name__ == "__main__":
    main()
