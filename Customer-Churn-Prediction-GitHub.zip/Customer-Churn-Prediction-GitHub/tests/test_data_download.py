from src.download_data import URL


def test_dataset_source_is_IBM():
    assert URL.startswith("https://raw.githubusercontent.com/IBM/")
    assert URL.endswith("Telco-Customer-Churn.csv")
