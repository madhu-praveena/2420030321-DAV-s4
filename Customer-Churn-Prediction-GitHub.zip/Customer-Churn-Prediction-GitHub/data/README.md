# Data directory

Run `python -m src.download_data` from the repository root to download the IBM Telco Customer Churn CSV into `data/raw/`.

The raw data file is intentionally excluded from Git by `.gitignore`. Keep the downloaded source file unchanged; cleaning and preprocessing are performed in memory by the analysis pipeline.
