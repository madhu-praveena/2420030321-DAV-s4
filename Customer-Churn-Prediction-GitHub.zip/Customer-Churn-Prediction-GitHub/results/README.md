# Experiment outputs

This folder is populated by `python -m src.train` after downloading the IBM dataset. No model metrics are committed as measured results before an actual run. This avoids confusing the illustrative values in the UI prototype with evaluated model performance.
