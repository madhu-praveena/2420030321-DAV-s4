# Dataset and data dictionary

## Source and scope

**Dataset:** IBM Telco Customer Churn sample  
**Publisher:** IBM  
**Records:** 7,043  
**Columns:** 21  
**Target:** `Churn` — `Yes` means the customer departed within the last month; `No` means they did not.

Official references:

- IBM sample documentation: https://www.ibm.com/docs/en/cognos-analytics/12.1.x?topic=samples-telco-customer-churn
- IBM source repository: https://github.com/IBM/telco-customer-churn-on-icp4d
- CSV: https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv

## Fields

| Column | Type | Meaning |
|---|---|---|
| `customerID` | Identifier | Unique customer ID; excluded from model predictors |
| `gender` | Categorical | Customer gender |
| `SeniorCitizen` | Binary integer | Senior-citizen indicator (0/1) |
| `Partner` | Categorical | Whether the customer has a partner |
| `Dependents` | Categorical | Whether the customer has dependents |
| `tenure` | Integer | Number of months with the company |
| `PhoneService` | Categorical | Whether phone service is subscribed |
| `MultipleLines` | Categorical | Multiple-line status |
| `InternetService` | Categorical | Internet service type |
| `OnlineSecurity` | Categorical | Online security add-on status |
| `OnlineBackup` | Categorical | Online backup add-on status |
| `DeviceProtection` | Categorical | Device protection add-on status |
| `TechSupport` | Categorical | Tech support add-on status |
| `StreamingTV` | Categorical | Streaming TV subscription status |
| `StreamingMovies` | Categorical | Streaming movies subscription status |
| `Contract` | Categorical | Contract duration/type |
| `PaperlessBilling` | Categorical | Paperless billing status |
| `PaymentMethod` | Categorical | Payment method |
| `MonthlyCharges` | Numeric | Current monthly charge |
| `TotalCharges` | Numeric-like text in source | Total amount charged; convert to numeric before analysis |
| `Churn` | Binary categorical target | Whether the customer left (Yes/No) |

## Data handling notes

- `customerID` is an identifier and is removed from the feature matrix.
- `TotalCharges` is parsed with `pandas.to_numeric(errors="coerce")`; blank/invalid entries become missing.
- Missing values are counted and written to `results/data_quality.json` before model fitting. The numeric median and categorical most-frequent imputers are fitted only on training data through scikit-learn pipelines.
- The target is mapped to 1/0 and is never scaled.
- Verify the downloaded file's shape and column names in the generated quality report before presenting results.
