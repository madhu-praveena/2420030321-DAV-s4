# Methodology

## 1. Business problem

Can customer information help identify customers who are likely to leave early enough for a retention team to act?

## 2. Data understanding

Inspect shape, first rows, dtypes, descriptive statistics, target distribution, missing-value counts and duplicate rows. The analysis code records these checks in `results/data_quality.json`.

## 3. Data preparation

- Remove the customer identifier from model predictors.
- Convert `TotalCharges` to numeric.
- Split into training and test subsets with an 80/20 stratified split and a fixed random seed.
- Use a `ColumnTransformer` inside a `Pipeline` to prevent preprocessing leakage.
- Impute numeric values with the median and categorical values with the most frequent category.
- One-hot encode categorical predictors.
- Standardise numeric values for Logistic Regression, SVM and KNN; leave numeric scale unchanged for tree-based models.

## 4. Exploratory and statistical checks

The pipeline records class counts and basic numeric summaries. Histograms and the churn distribution plot help inspect shape and imbalance. Use IQR fences to screen numeric columns for possible outliers:

`IQR = Q3 - Q1`; lower fence `= Q1 - 1.5 × IQR`; upper fence `= Q3 + 1.5 × IQR`.

Outliers should be investigated, not automatically deleted; high charges may be valid customer behaviour. Normality is not a requirement for tree-based classifiers.

## 5. Model comparison

The code compares Logistic Regression, Decision Tree, Random Forest, Support Vector Machine, K-Nearest Neighbors and XGBoost (if the package is available). All models use the same stratified split and test data.

## 6. Evaluation

- **Accuracy:** fraction of all predictions that are correct.
- **Precision:** fraction of predicted churners who actually churned.
- **Recall:** fraction of actual churners detected.
- **F1-score:** harmonic mean of precision and recall.
- **ROC-AUC:** ability to rank churners above non-churners.

For churn detection, recall and F1 are important because failing to identify a customer who leaves can be costly. Accuracy alone is insufficient when classes are imbalanced.

## 7. Model selection

The script ranks models by test F1-score, then recall, then ROC-AUC. The selected model is saved as `models/best_model.joblib`; the actual measured scores are written to `results/model_metrics.csv`.

## 8. Limitations

This is a cross-sectional sample and does not contain repeated monthly snapshots for temporal validation. Test-set performance is not a guarantee of future performance. Feature associations are not causal explanations, and model predictions should support—not replace—human retention decisions.
